# app.py - Updated Main Flask Application
import os
from flask import Flask, render_template, redirect, url_for, session, flash
from werkzeug.security import generate_password_hash
import sqlite3
from datetime import datetime
# Import blueprints
from blueprints.auth import auth_bp
from blueprints.main import main_bp
from blueprints.dashboard import dashboard_bp
from blueprints.chatbot import chatbot_bp  # Import chatbot blueprint

def create_app():
   app = Flask(__name__)
   app.secret_key = os.environ.get('SECRET_KEY', 'your-secret-key-change-in-production')
   
   # Initialize database
   init_database()
   
   # Register blueprints
   app.register_blueprint(auth_bp, url_prefix='/auth')
   app.register_blueprint(main_bp)
   app.register_blueprint(dashboard_bp, url_prefix='/dashboard')
   app.register_blueprint(chatbot_bp, url_prefix='/chatbot')  # Register chatbot blueprint
   
   # Global context processor for user session
   @app.context_processor
   def inject_user():
       return dict(user_id=session.get('user_id'), 
                  username=session.get('username'))
   
   # Error handlers
   @app.errorhandler(404)
   def not_found(error):
       return render_template('errors/404.html'), 404
   
   @app.errorhandler(500)
   def internal_error(error):
       return render_template('errors/500.html'), 500
   
   return app

def init_database():
   """Initialize SQLite database with required tables"""
   conn = sqlite3.connect('app.db')
   cursor = conn.cursor()
   
   # Users table
   cursor.execute('''
       CREATE TABLE IF NOT EXISTS users (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           username TEXT UNIQUE NOT NULL,
           email TEXT UNIQUE NOT NULL,
           password_hash TEXT NOT NULL,
           created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
           is_active BOOLEAN DEFAULT 1
       )
   ''')
   
   # User sessions table
   cursor.execute('''
       CREATE TABLE IF NOT EXISTS user_sessions (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           user_id INTEGER,
           session_data TEXT,
           created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
           FOREIGN KEY (user_id) REFERENCES users (id)
       )
   ''')
   
   conn.commit()
   conn.close()

if __name__ == '__main__':
   app = create_app()
   # Try multiple ports until one works
   ports = [3000, 4000, 5001, 8000, 8888, 9000, 8080]
   for port in ports:
       try:
           print(f"Trying to start server on port {port}...")
           app.run(debug=True, host='127.0.0.1', port=port)
           break
       except OSError as e:
           print(f"Port {port} failed: {e}")
           if port == ports[-1]:  # Last port
               print("All ports failed. Try running as administrator.")
           continue