# blueprints/chatbot.py - Chatbot Blueprint
import os
import sqlite3
import json
import re
from datetime import datetime
from flask import Blueprint, render_template, request, jsonify, session
from youtube_transcript_api import YouTubeTranscriptApi
from huggingface_hub import InferenceClient
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from nltk.stem import WordNetLemmatizer
import uuid
from blueprints.auth import login_required

# Initialize blueprint
chatbot_bp = Blueprint('chatbot', __name__)

# Initialize HuggingFace client
client = InferenceClient(
    provider="cohere",
    api_key= "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",
)

# Initialize NLTK components (with error handling)
try:
    nltk.data.find('tokenizers/punkt')
except LookupError:
    nltk.download('punkt')

try:
    nltk.data.find('corpora/stopwords')
except LookupError:
    nltk.download('stopwords')

try:
    nltk.data.find('corpora/wordnet')
except LookupError:
    nltk.download('wordnet')

lemmatizer = WordNetLemmatizer()
stop_words = set(stopwords.words('english'))

class ChatbotDatabaseManager:
    def __init__(self, db_path='app.db'):
        self.db_path = db_path
        self.init_chatbot_tables()
    
    def init_chatbot_tables(self):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Videos table for chatbot
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chatbot_videos (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                video_id TEXT UNIQUE,
                title TEXT,
                transcript TEXT,
                processed_content TEXT,
                user_id INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Chat sessions table for chatbot
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS chatbot_sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id TEXT,
                video_id TEXT,
                user_id INTEGER,
                message TEXT,
                response TEXT,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (video_id) REFERENCES chatbot_videos (video_id),
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def save_video_data(self, video_id, title, transcript, processed_content, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT OR REPLACE INTO chatbot_videos (video_id, title, transcript, processed_content, user_id)
            VALUES (?, ?, ?, ?, ?)
        ''', (video_id, title, transcript, processed_content, user_id))
        
        conn.commit()
        conn.close()
    
    def get_video_data(self, video_id, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM chatbot_videos WHERE video_id = ? AND user_id = ?', 
            (video_id, user_id)
        )
        result = cursor.fetchone()
        
        conn.close()
        return result
    
    def save_chat_message(self, session_id, video_id, user_id, message, response):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO chatbot_sessions (session_id, video_id, user_id, message, response)
            VALUES (?, ?, ?, ?, ?)
        ''', (session_id, video_id, user_id, message, response))
        
        conn.commit()
        conn.close()
    
    def get_chat_history(self, session_id, video_id, user_id):
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT message, response FROM chatbot_sessions 
            WHERE session_id = ? AND video_id = ? AND user_id = ?
            ORDER BY timestamp
        ''', (session_id, video_id, user_id))
        
        results = cursor.fetchall()
        conn.close()
        return results

class TranscriptProcessor:
    def __init__(self):
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = set(stopwords.words('english'))
    
    def extract_youtube_id(self, url):
        """Extract YouTube video ID from URL"""
        patterns = [
            r'(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([^&\n?#]+)',
            r'youtube\.com\/watch\?.*v=([^&\n?#]+)'
        ]
        
        for pattern in patterns:
            match = re.search(pattern, url)
            if match:
                return match.group(1)
        return None
    
    def get_transcript(self, video_id):
        """Get transcript from YouTube video"""
        try:
            # Create an instance of YouTubeTranscriptApi and use fetch method
            ytt_api = YouTubeTranscriptApi()
            fetched_transcript = ytt_api.fetch(video_id)
            # Convert to raw data format for compatibility
            transcript_list = fetched_transcript.to_raw_data()
            transcript_text = ' '.join([item['text'] for item in transcript_list])
            return transcript_text, transcript_list
        except Exception as e:
            raise Exception(f"Error fetching transcript: {str(e)}")
    
    def process_transcript(self, transcript_text):
        """Process transcript text for better understanding"""
        # Tokenize into sentences
        sentences = sent_tokenize(transcript_text)
        
        # Process each sentence
        processed_sentences = []
        key_concepts = []
        
        for sentence in sentences:
            # Clean and tokenize
            words = word_tokenize(sentence.lower())
            
            # Remove stop words and lemmatize
            filtered_words = [
                self.lemmatizer.lemmatize(word) 
                for word in words 
                if word.isalnum() and word not in self.stop_words
            ]
            
            if filtered_words:
                processed_sentences.append({
                    'original': sentence,
                    'processed': ' '.join(filtered_words),
                    'keywords': filtered_words
                })
                key_concepts.extend(filtered_words)
        
        # Get unique key concepts
        unique_concepts = list(set(key_concepts))
        
        return {
            'sentences': processed_sentences,
            'key_concepts': unique_concepts,
            'summary': self.generate_summary(processed_sentences)
        }
    
    def generate_summary(self, processed_sentences):
        """Generate a brief summary of key points"""
        if len(processed_sentences) < 5:
            return "Short content - summary not needed"
        
        # Take first, middle, and last sentences for basic summary
        key_sentences = [
            processed_sentences[0]['original'],
            processed_sentences[len(processed_sentences)//2]['original'],
            processed_sentences[-1]['original']
        ]
        
        return ' '.join(key_sentences)

class ChatbotTutor:
    def __init__(self, client):
        self.client = client
        self.system_prompt = """You are an intelligent tutoring chatbot designed to help students learn from educational video content. Your role is to:

1. Answer questions about the video content accurately and clearly
2. Provide summaries when requested
3. Generate quiz questions to test understanding
4. Ask follow-up questions to check comprehension
5. Encourage active learning and engagement

Guidelines:
- Keep responses concise but informative
- Use the video transcript context to provide accurate answers
- When generating quizzes, create multiple-choice or short-answer questions
- Be encouraging and supportive in your tone
- If asked about content not in the video, politely redirect to the video material
- Suggest related concepts or ask clarifying questions when appropriate

The student is watching an educational video, and you have access to the full transcript."""
    
    def generate_response(self, user_message, video_context, chat_history):
        """Generate chatbot response using HuggingFace API"""
        try:
            # Prepare context with video content
            context = f"""
Video Content Summary: {video_context.get('summary', 'No summary available')}

Key Concepts: {', '.join(video_context.get('key_concepts', [])[:10])}

Recent Chat History:
{self.format_chat_history(chat_history)}

Student Question: {user_message}
"""
            
            messages = [
                {"role": "system", "content": self.system_prompt},
                {"role": "user", "content": context}
            ]
            
            completion = self.client.chat.completions.create(
                model="CohereLabs/c4ai-command-r-plus",
                messages=messages,
                max_tokens=300,
                temperature=0.7
            )
            
            response = completion.choices[0].message.content
            return response
            
        except Exception as e:
            return f"I'm having trouble processing your request right now. Could you please rephrase your question? Error: {str(e)}"
    
    def format_chat_history(self, chat_history):
        """Format chat history for context"""
        if not chat_history:
            return "No previous conversation"
        
        formatted = []
        for message, response in chat_history[-3:]:  # Last 3 exchanges
            formatted.append(f"Student: {message}")
            formatted.append(f"Tutor: {response}")
        
        return '\n'.join(formatted)
    
    def generate_quiz_question(self, video_context):
        """Generate a quiz question based on video content"""
        try:
            quiz_prompt = f"""
Based on the following video content, generate ONE multiple-choice quiz question to test student understanding:

Key Concepts: {', '.join(video_context.get('key_concepts', [])[:15])}
Summary: {video_context.get('summary', '')}

Format your response as:
Question: [Your question here]
A) [Option A]
B) [Option B] 
C) [Option C]
D) [Option D]
Correct Answer: [Letter]
Explanation: [Brief explanation]
"""
            
            messages = [
                {"role": "system", "content": "You are an educational content creator. Generate clear, relevant quiz questions."},
                {"role": "user", "content": quiz_prompt}
            ]
            
            completion = self.client.chat.completions.create(
                model="CohereLabs/c4ai-command-r-plus",
                messages=messages,
                max_tokens=400,
                temperature=0.8
            )
            
            return completion.choices[0].message.content
            
        except Exception as e:
            return "I can't generate a quiz question right now. Please ask me any questions about the video content!"

# Initialize components
db_manager = ChatbotDatabaseManager()
transcript_processor = TranscriptProcessor()
chatbot = ChatbotTutor(client)

@chatbot_bp.route('/')
@login_required
def index():
    """Chatbot home page - YouTube URL input"""
    return render_template('chatbot/index.html')

@chatbot_bp.route('/process_video', methods=['POST'])
@login_required
def process_video():
    try:
        data = request.get_json()
        youtube_url = data.get('youtube_url')
        
        if not youtube_url:
            return jsonify({'error': 'YouTube URL is required'}), 400
        
        # Extract video ID
        video_id = transcript_processor.extract_youtube_id(youtube_url)
        if not video_id:
            return jsonify({'error': 'Invalid YouTube URL'}), 400
        
        user_id = session['user_id']
        
        # Check if video already processed by this user
        existing_data = db_manager.get_video_data(video_id, user_id)
        if existing_data:
            processed_content = json.loads(existing_data[4])
            return jsonify({
                'success': True,
                'video_id': video_id,
                'title': existing_data[2],
                'processed_content': processed_content
            })
        
        # Get transcript
        transcript_text, transcript_list = transcript_processor.get_transcript(video_id)
        
        # Process transcript
        processed_content = transcript_processor.process_transcript(transcript_text)
        
        # Save to database
        db_manager.save_video_data(
            video_id, 
            f"Video {video_id}", 
            transcript_text,
            json.dumps(processed_content),
            user_id
        )
        
        # Generate session ID
        if 'chatbot_session_id' not in session:
            session['chatbot_session_id'] = str(uuid.uuid4())
        
        return jsonify({
            'success': True,
            'video_id': video_id,
            'title': f"Video {video_id}",
            'processed_content': processed_content
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chatbot_bp.route('/chat', methods=['POST'])
@login_required
def chat():
    try:
        data = request.get_json()
        message = data.get('message')
        video_id = data.get('video_id')
        
        if not message or not video_id:
            return jsonify({'error': 'Message and video_id are required'}), 400
        
        user_id = session['user_id']
        
        # Get session ID
        if 'chatbot_session_id' not in session:
            session['chatbot_session_id'] = str(uuid.uuid4())
        session_id = session['chatbot_session_id']
        
        # Get video context
        video_data = db_manager.get_video_data(video_id, user_id)
        if not video_data:
            return jsonify({'error': 'Video not found'}), 404
        
        processed_content = json.loads(video_data[4])
        
        # Get chat history
        chat_history = db_manager.get_chat_history(session_id, video_id, user_id)
        
        # Generate response
        if message.lower() in ['quiz', 'generate quiz', 'test me', 'quiz question']:
            response = chatbot.generate_quiz_question(processed_content)
        else:
            response = chatbot.generate_response(message, processed_content, chat_history)
        
        # Save chat message
        db_manager.save_chat_message(session_id, video_id, user_id, message, response)
        
        return jsonify({
            'success': True,
            'response': response
        })
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@chatbot_bp.route('/video/<video_id>')
@login_required
def video_page(video_id):
    """Video page with embedded player and chatbot"""
    user_id = session['user_id']
    
    # Get video data
    video_data = db_manager.get_video_data(video_id, user_id)
    if not video_data:
        return "Video not found", 404
    
    return render_template('chatbot/video.html', video_id=video_id, title=video_data[2])

@chatbot_bp.route('/history')
@login_required
def history():
    """User's chatbot history"""
    user_id = session['user_id']
    
    conn = sqlite3.connect('app.db')
    cursor = conn.cursor()
    
    # Get user's videos
    cursor.execute(
        'SELECT video_id, title, created_at FROM chatbot_videos WHERE user_id = ? ORDER BY created_at DESC',
        (user_id,)
    )
    videos = cursor.fetchall()
    conn.close()
    
    return render_template('chatbot/history.html', videos=videos)