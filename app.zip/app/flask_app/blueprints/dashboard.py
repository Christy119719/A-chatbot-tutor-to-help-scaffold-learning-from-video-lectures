# blueprints/dashboard.py - Dashboard Blueprint
from flask import Blueprint, render_template, session, redirect, url_for, request, flash
from blueprints.auth import login_required
import sqlite3

dashboard_bp = Blueprint('dashboard', __name__)

def get_db_connection():
    conn = sqlite3.connect('app.db')
    conn.row_factory = sqlite3.Row
    return conn

@dashboard_bp.route('/')
@login_required
def index():
    """Main dashboard page"""
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE id = ?',
        (session['user_id'],)
    ).fetchone()
    conn.close()
    
    return render_template('dashboard/index.html', user=user)

@dashboard_bp.route('/profile')
@login_required
def profile():
    """User profile page"""
    conn = get_db_connection()
    user = conn.execute(
        'SELECT * FROM users WHERE id = ?',
        (session['user_id'],)
    ).fetchone()
    conn.close()
    
    return render_template('dashboard/profile.html', user=user)

@dashboard_bp.route('/profile/edit', methods=['GET', 'POST'])
@login_required
def edit_profile():
    """Edit user profile"""
    conn = get_db_connection()
    
    if request.method == 'POST':
        username = request.form.get('username', '').strip()
        email = request.form.get('email', '').strip().lower()
        
        if not username or not email:
            flash('Please fill in all fields', 'error')
        else:
            try:
                conn.execute(
                    'UPDATE users SET username = ?, email = ? WHERE id = ?',
                    (username, email, session['user_id'])
                )
                conn.commit()
                session['username'] = username
                flash('Profile updated successfully!', 'success')
                return redirect(url_for('dashboard.profile'))
            except sqlite3.IntegrityError:
                flash('Username or email already exists', 'error')
    
    user = conn.execute(
        'SELECT * FROM users WHERE id = ?',
        (session['user_id'],)
    ).fetchone()
    conn.close()
    
    return render_template('dashboard/edit_profile.html', user=user)

@dashboard_bp.route('/settings')
@login_required
def settings():
    """User settings page"""
    return render_template('dashboard/settings.html')